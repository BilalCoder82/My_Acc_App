#!/usr/bin/env python3
"""dl005_counter.py — أداة قياس مستقلة (قراءة فقط) لاستثناءات التكلفة التاريخية.

تقيس على نسخة من قاعدة بيانات SQLite كم من حركات المخزون ستُعامَل كاستثناء
(DL-003) أو تُوسَم بالتسميم (DL-005)، وكم من أحداث التصحيح ستُحجَب بسببها.

الاستخدام (من جذر المشروع، على **نسخة** من ملف القاعدة):
    python dl005_counter.py مسار_النسخة.db
    python dl005_counter.py مسار_النسخة.db --json out.json --map-out map.txt
    python dl005_counter.py مسار_النسخة.db --sample 50      # عيّنة لكل صنف (قواعد كبيرة)

ضمانات:
- القاعدة تُفتح بوضع القراءة فقط (SQLite mode=ro) وتُنسَخ إلى ذاكرة RAM؛ كل
  الكتابة التي يجريها المحرك أثناء الحساب تقع على نسخة الذاكرة وتُتجاهَل. تُطبَع
  بصمة SHA-256 للملف قبل/بعد للتدليل على أنه لم يتغيّر.
- لا تعديل لقواعد التصحيح ولا ترحيلات ولا تغيير حالة أي حدث في القاعدة.
- منطق الاستثناء هو منطق candidate_engine.build_candidate نفسه (لا قاعدة
  موازية). الكمية قبل كل OUT تُحسَب خارجياً **للتصنيف فقط** (مباشر/تسميم)،
  وتُقارَن بقرار المحرك كفحص ذاتي (يجب ألا يوجد تناقض).
- الإخراج مجمَّع: أعداد ونسب وتواريخ. الأصناف والمستودعات بتسميات مجهولة
  (item#k / W#j)؛ جدول التسميات يُكتب في ملف محلي فقط إن طلبتَ --map-out.

ثلاثة قياسات مختلفة (لا تُخلَط):
  A) قياس مباشر لحركات موجودة — بلا أي محاكاة لأحداث.
  B) محاكاة: كل حركة "مؤهَّلة" تُعامَل كأنها أُدخلت بأثر رجعي (نفس شرط
     correction_detection) ويُبنى لها حدث افتراضي بالمحرك الفعلي.
  C) أحداث تصحيح حقيقية موجودة فعلاً في القاعدة.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import sys
import time
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy import create_engine, inspect, select  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402
from sqlalchemy.pool import StaticPool  # noqa: E402

from app.models import (  # noqa: E402
    Base, CorrectionEvent, CorrectionEventDeltaRecord, CorrectionEventImpactScopeElement,
    CorrectionEventRootCause, CorrectionEventStatus, InventoryMovement, MovementDirection,
    RootCauseComponentType,
)
from app.services.candidate_engine import build_candidate  # noqa: E402
from app.services.correction_scope import build_impact_scope  # noqa: E402

_ZERO = Decimal("0")


# ---------------------------------------------------------------------------
# فتح القاعدة: قراءة فقط → نسخة في الذاكرة
# ---------------------------------------------------------------------------
def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def open_readonly_to_memory(path: str) -> sqlite3.Connection:
    uri = Path(path).resolve().as_uri()
    src = None
    for suffix in ("?mode=ro", "?mode=ro&immutable=1"):      # immutable: ملف WAL بلا صلاحية كتابة
        try:
            src = sqlite3.connect(uri + suffix, uri=True)
            src.execute("SELECT count(*) FROM sqlite_master").fetchone()
            break
        except sqlite3.Error:
            src = None
    if src is None:
        raise SystemExit("❌ تعذّر فتح الملف بوضع القراءة فقط (تأكد أنه ملف SQLite سليم).")
    mem = sqlite3.connect(":memory:", check_same_thread=False)
    src.backup(mem)
    src.close()
    return mem


def make_session(mem: sqlite3.Connection):
    engine = create_engine("sqlite://", creator=lambda: mem, poolclass=StaticPool)
    existing = set(inspect(engine).get_table_names())
    # جداول ناقصة (قاعدة أقدم من G-007) تُنشأ في نسخة الذاكرة فقط — لا أثر على الملف
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)(), sorted(set(Base.metadata.tables) - existing)


# ---------------------------------------------------------------------------
# محاكاة حدث بالمحرك الفعلي (الكتابة تقع على نسخة الذاكرة ثم تُلغى)
# ---------------------------------------------------------------------------
def simulate(session, item_id: int, root_movement_id: int):
    """→ ("ok", [(movement_id, exception)]) أو ("unevaluable", سبب عام)."""
    ev = CorrectionEvent(item_id=item_id, trigger_type="dl005_counter",
                         status=CorrectionEventStatus.CANDIDATE)
    session.add(ev)
    session.flush()
    session.add(CorrectionEventRootCause(
        correction_event_id=ev.id, component_type=RootCauseComponentType.NEW_MOVEMENT,
        source_type="inventory_movement", source_id=root_movement_id))
    session.flush()
    try:
        build_impact_scope(session, ev.id)
        return _evaluate_event(session, ev.id)
    except ValueError as e:
        return "unevaluable", _reason(str(e))
    finally:
        session.rollback()


def _evaluate_event(session, event_id: int):
    cand = build_candidate(session, event_id)
    rows = session.execute(
        select(CorrectionEventDeltaRecord.movement_id,
               CorrectionEventDeltaRecord.cost_basis_exception)
        .where(CorrectionEventDeltaRecord.candidate_state_id == cand.id)).all()
    return "ok", [(r[0], bool(r[1])) for r in rows]


def _reason(msg: str) -> str:
    if "ليست لاحقة متصلة" in msg:
        return "نطاق غير متصل"
    if "دورة تبعية" in msg:
        return "دورة تبعية تحويلات"
    if "ImpactScope فارغ" in msg:
        return "نطاق فارغ"
    return "سبب آخر"


# ---------------------------------------------------------------------------
# تحميل الحركات (ORM بنفس أنواع الأعمدة التي يقارنها المحرك)
# ---------------------------------------------------------------------------
def load_movements(session):
    mv: dict[int, dict] = {}
    pairs: dict[tuple[int, int], list[int]] = defaultdict(list)
    for m in session.execute(select(InventoryMovement)).scalars().all():
        mv[m.id] = {
            "id": m.id, "item": m.item_id, "wh": m.warehouse_id,
            "out": m.direction == MovementDirection.OUT,
            "qty": Decimal(str(m.quantity)), "date": m.movement_date,
            "src": m.source_type,
        }
        pairs[(m.item_id, m.warehouse_id)].append(m.id)
    session.expunge_all()
    qbefore: dict[int, Decimal] = {}
    for key, ids in pairs.items():
        ids.sort(key=lambda i: (mv[i]["date"], i))            # نفس ترتيب المحرك
        q = _ZERO
        for i in ids:
            qbefore[i] = q
            q += (-1 if mv[i]["out"] else 1) * mv[i]["qty"]
    return mv, pairs, qbefore


def _is_transfer_out(m: dict) -> bool:
    """جذر من هذا النوع لا يعبر نطاقه إلى مستودع الوجهة (قصور معروف في
    correction_scope: الجذر يُعلَّم زائراً قبل حلقة العبور فيُتخطّى)."""
    return m["out"] and m["src"] == "stock_transfer"


def _as_date(x):
    return x.date() if hasattr(x, "hour") else x


def _iso(d) -> str:
    return d.isoformat()[:10] if d is not None else "—"


def _pct(a, b) -> str:
    return f"{(100.0 * a / b):.1f}%" if b else "—"


# ---------------------------------------------------------------------------
# A) قياس مباشر لحركات موجودة
# ---------------------------------------------------------------------------
def measure_A(session, mv, pairs, qbefore, progress):
    by_item: dict[int, list[int]] = defaultdict(list)
    for (item, wh) in pairs:
        by_item[item].append(wh)
    exc: set[int] = set()
    unevaluable = Counter()
    evaluated_pairs: set[tuple[int, int]] = set()
    transfer_roots = 0
    n = 0
    for item, whs in by_item.items():
        for wh in whs:
            ids = pairs[(item, wh)]
            root = min(ids, key=lambda i: (mv[i]["date"], i))
            if _is_transfer_out(mv[root]):
                transfer_roots += 1
            status, payload = simulate(session, item, root)
            n += 1
            progress("A", n, len(pairs))
            if status != "ok":
                unevaluable[payload] += 1
                continue
            evaluated_pairs.add((item, wh))
            exc.update(m for m, flag in payload if flag)
    return exc, evaluated_pairs, unevaluable, transfer_roots


def summarize_A(mv, pairs, qbefore, exc, evaluated_pairs, unevaluable, wlabel, ilabel):
    out_total = Counter(); mov_total = Counter()
    direct = Counter(); poisoned = Counter(); inherited = Counter()
    pair_rows = []
    contradictions = 0
    for (item, wh), ids in pairs.items():
        for i in ids:
            mov_total[wh] += 1
            if mv[i]["out"]:
                out_total[wh] += 1
        if (item, wh) not in evaluated_pairs:
            continue
        p_direct = p_pois = p_inh = 0
        first_exc = None
        for i in ids:
            m = mv[i]
            if m["out"] and qbefore[i] <= 0 and i not in exc:
                contradictions += 1          # فحص ذاتي: المحرك لم يُعلِّم OUT كميته السابقة ≤ 0
            if i in exc:
                key = (m["date"], i)
                first_exc = key if first_exc is None or key < first_exc else first_exc
                if m["out"] and qbefore[i] <= 0:
                    direct[wh] += 1; p_direct += 1
                elif m["out"]:
                    poisoned[wh] += 1; p_pois += 1
                else:
                    inherited[wh] += 1; p_inh += 1
        if first_exc is not None:
            n_out = sum(1 for i in ids if mv[i]["out"])
            pair_rows.append({
                "item": ilabel[item], "wh": wlabel[wh], "first_exception": _iso(first_exc[0]),
                "out_total": n_out, "direct": p_direct, "poisoned": p_pois,
                "inherited_in": p_inh,
            })
    per_wh = []
    for wh in sorted(wlabel, key=lambda w: wlabel[w]):
        pw = [r for r in pair_rows if r["wh"] == wlabel[wh]]
        n_pairs = sum(1 for (it, w) in evaluated_pairs if w == wh)
        per_wh.append({
            "wh": wlabel[wh], "movements": mov_total[wh], "out": out_total[wh],
            "direct": direct[wh], "poisoned": poisoned[wh], "inherited_in": inherited[wh],
            "pairs": n_pairs, "pairs_with_exception": len(pw),
        })
    return per_wh, sorted(pair_rows, key=lambda r: -(r["direct"] + r["poisoned"])), contradictions


# ---------------------------------------------------------------------------
# B) محاكاة: كل حركة مؤهَّلة كأنها أُدخلت بأثر رجعي
# ---------------------------------------------------------------------------
def measure_B(session, mv, pairs, qbefore, sample, max_seconds, progress, t0, since=None):
    """مؤهَّلة = يوجد في نفس (صنف، مستودع) حركة بتاريخ أحدث (شرط
    correction_detection نفسه). حركات نفس (صنف، مستودع، تاريخ) تُنتج النطاق
    ذاته فتُحاكى مرة واحدة بوزن عددها. المقام: أحداث نطاقها يحوي ≥ 1 بيع
    خارجي (sales_invoice OUT) فقط — غيرها بلا تعرّض لـCOGS."""
    groups: dict[int, dict] = defaultdict(dict)            # item -> (wh,date) -> [ids]
    for (item, wh), ids in pairs.items():
        dates = sorted({mv[i]["date"] for i in ids})
        for i in ids:
            if any(d > mv[i]["date"] for d in dates):       # يوجد لاحق بتاريخ أكبر
                if since is not None and _as_date(mv[i]["date"]) < since:
                    continue                                # خارج نافذة المحاكاة المطلوبة
                groups[item].setdefault((wh, mv[i]["date"]), []).append(i)
    total_groups = sum(len(g) for g in groups.values())
    per_item = {}
    done = 0
    partial = False
    for item, g in groups.items():
        keys = sorted(g, key=lambda k: (k[1], k[0]))
        if sample and len(keys) > sample:
            idx = sorted({round(i * (len(keys) - 1) / (sample - 1)) for i in range(sample)}) if sample > 1 else [0]
            keys = [keys[i] for i in idx]
        stats = {"eligible": 0, "blocked": 0, "no_sales_out": 0, "unevaluable": Counter(),
                 "blocked_dates": [], "eligible_dates": [], "blocked_direct": 0,
                 "sampled": len(keys), "groups": len(g), "transfer_root": 0}
        for k in keys:
            if max_seconds and time.time() - t0 > max_seconds:
                partial = True
                break
            ids = g[k]
            # مجموعة فيها ساق تحويل OUT: الجذر يغيّر النطاق ⟹ كل حركة تُحاكى كجذر بوزن 1
            if any(_is_transfer_out(mv[i]) for i in ids):
                units = [(i, 1) for i in ids]
            else:
                units = [(ids[0], len(ids))]
            for root_id, w in units:
                status, payload = simulate(session, item, root_id)
                done += 1
                progress("B", done, total_groups)
                if status != "ok":
                    stats["unevaluable"][payload] += w
                    continue
                scope_ids = [m for m, _ in payload]
                if _is_transfer_out(mv[root_id]):
                    stats["transfer_root"] += w          # يُحصى حتى لو استُبعد: القصور قد يُخفي بيع الوجهة
                if not any(mv[m]["out"] and mv[m]["src"] == "sales_invoice" for m in scope_ids):
                    stats["no_sales_out"] += w
                    continue
                exc_ids = [m for m, flag in payload if flag]
                stats["eligible"] += w
                stats["eligible_dates"].append(k[1])
                if exc_ids:
                    stats["blocked"] += w
                    stats["blocked_dates"].append(k[1])
                    if any(mv[m]["out"] and qbefore[m] <= 0 for m in exc_ids):
                        stats["blocked_direct"] += w     # DL-003 وحده كان سيحجبه
        per_item[item] = stats
        if partial:
            break
    return per_item, partial


# ---------------------------------------------------------------------------
# C) أحداث تصحيح حقيقية موجودة في القاعدة
# ---------------------------------------------------------------------------
def measure_C(session, mv, progress):
    ev_rows = session.execute(
        select(CorrectionEvent.id, CorrectionEvent.item_id, CorrectionEvent.status)).all()
    result = {"total": len(ev_rows), "by_status": Counter(), "eligible": 0, "blocked": 0,
              "no_sales_out": 0, "unevaluable": Counter(), "unsupported_root": 0,
              "transfer_root": 0}
    n = 0
    for ev_id, item_id, status in ev_rows:
        result["by_status"][status.value if hasattr(status, "value") else str(status)] += 1
        n += 1
        progress("C", n, len(ev_rows))
        root = session.execute(select(CorrectionEventRootCause).where(
            CorrectionEventRootCause.correction_event_id == ev_id)).scalars().first()
        if root is None or root.source_type != "inventory_movement":
            result["unsupported_root"] += 1
            continue
        if root.source_id in mv and _is_transfer_out(mv[root.source_id]):
            result["transfer_root"] += 1
        try:
            has_scope = session.execute(select(CorrectionEventImpactScopeElement.id).where(
                CorrectionEventImpactScopeElement.correction_event_id == ev_id).limit(1)).first()
            if not has_scope:
                build_impact_scope(session, ev_id)
            st, payload = _evaluate_event(session, ev_id)
        except ValueError as e:
            result["unevaluable"][_reason(str(e))] += 1
            session.rollback()
            continue
        session.rollback()
        scope_ids = [m for m, _ in payload]
        if not any(mv[m]["out"] and mv[m]["src"] == "sales_invoice" for m in scope_ids if m in mv):
            result["no_sales_out"] += 1
            continue
        result["eligible"] += 1
        if any(flag for _, flag in payload):
            result["blocked"] += 1
    return result


# ---------------------------------------------------------------------------
# التقرير
# ---------------------------------------------------------------------------
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="قياس استثناءات DL-003/DL-005 (قراءة فقط).")
    ap.add_argument("db", help="مسار **نسخة** من ملف SQLite")
    ap.add_argument("--json", help="اكتب النتائج المجمَّعة في ملف JSON")
    ap.add_argument("--map-out", help="اكتب جدول التسميات (item#k/W#j → المعرّف) في ملف محلي فقط")
    ap.add_argument("--sample", type=int, default=0, help="حدّ المحاكاة لكل صنف (عيّنة موزَّعة بالتساوي)")
    ap.add_argument("--since", help="YYYY-MM-DD: حاكِ فقط أحداثاً افتراضية جذرها من هذا التاريخ (أسرع بكثير)")
    ap.add_argument("--max-seconds", type=int, default=0, help="سقف زمني للمحاكاة B (0 = بلا سقف)")
    ap.add_argument("--top", type=int, default=15, help="عدد الأسطر في الجداول التفصيلية")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args(argv)

    if not os.path.isfile(args.db):
        print("❌ الملف غير موجود:", args.db)
        return 2
    since = None
    if args.since:
        try:
            since = __import__("datetime").date.fromisoformat(args.since)
        except ValueError:
            print("❌ --since بصيغة YYYY-MM-DD"); return 2
    sha_before = _sha256(args.db)
    t0 = time.time()

    def progress(tag, n, total):
        if not args.quiet and (n % 100 == 0 or n == total):
            print(f"  [{tag}] {n}/{total}", file=sys.stderr)

    mem = open_readonly_to_memory(args.db)
    try:
        version = mem.execute("SELECT version_num FROM alembic_version").fetchone()
    except sqlite3.Error:
        version = None
    session, created = make_session(mem)
    mv, pairs, qbefore = load_movements(session)
    if not mv:
        print("لا توجد حركات مخزون في هذه القاعدة — لا شيء للقياس.")
        return 0

    # تسميات مجهولة: مستودع/صنف مرتَّبان بعدد الحركات
    wh_count = Counter(m["wh"] for m in mv.values())
    wlabel = {w: f"W{k}" for k, (w, _) in enumerate(wh_count.most_common(), 1)}
    it_count = Counter(m["item"] for m in mv.values())
    ilabel = {i: f"item#{k}" for k, (i, _) in enumerate(it_count.most_common(), 1)}

    excA, evaluated, unevA, trootA = measure_A(session, mv, pairs, qbefore, progress)
    per_wh, pair_rows, contradictions = summarize_A(
        mv, pairs, qbefore, excA, evaluated, unevA, wlabel, ilabel)
    per_item, partial = measure_B(session, mv, pairs, qbefore, args.sample,
                                  args.max_seconds, progress, t0, since)
    real = measure_C(session, mv, progress)

    sha_after = _sha256(args.db)

    # ---- تجميع B ----
    E = sum(s["eligible"] for s in per_item.values())
    B = sum(s["blocked"] for s in per_item.values())
    Bd = sum(s["blocked_direct"] for s in per_item.values())
    NS = sum(s["no_sales_out"] for s in per_item.values())
    trootB = sum(s["transfer_root"] for s in per_item.values())
    unevB = Counter()
    for s in per_item.values():
        unevB.update(s["unevaluable"])
    rows_B = []
    for item, s in per_item.items():
        if s["eligible"] == 0 and not s["unevaluable"] and not s["no_sales_out"]:
            continue
        rows_B.append({
            "item": ilabel[item], "eligible": s["eligible"], "blocked": s["blocked"],
            "ratio": (100.0 * s["blocked"] / s["eligible"]) if s["eligible"] else None,
            "blocked_from": _iso(min(s["blocked_dates"])) if s["blocked_dates"] else None,
            "blocked_to": _iso(max(s["blocked_dates"])) if s["blocked_dates"] else None,
            "eligible_from": _iso(min(s["eligible_dates"])) if s["eligible_dates"] else None,
            "eligible_to": _iso(max(s["eligible_dates"])) if s["eligible_dates"] else None,
            "sampled": s["sampled"], "groups": s["groups"],
        })
    rows_B.sort(key=lambda r: (-r["blocked"], r["item"]))
    items_with_elig = [r for r in rows_B if r["eligible"] > 0]
    buckets = Counter()
    for r in items_with_elig:
        x = r["ratio"]
        buckets["0%" if x == 0 else "حتى 25%" if x <= 25 else "25–50%" if x <= 50
                else "50–75%" if x <= 75 else "75–100% (غير شاملة)" if x < 100 else "100%"] += 1

    # ---- الطباعة ----
    P = print
    P("=" * 72)
    P("تقرير قياس DL-003 / DL-005 — قراءة فقط، مجمَّع بلا أسماء")
    P("=" * 72)
    P(f"الملف: لم يتغيّر ({'SHA-256 متطابق قبل/بعد' if sha_before == sha_after else '⚠️ البصمة تغيّرت!'})")
    P(f"إصدار المخطط: {version[0] if version else 'غير معروف'}"
      + (f" | جداول أُنشئت في نسخة الذاكرة فقط: {len(created)}" if created else ""))
    P(f"حركات المخزون: {len(mv)} | أزواج (صنف، مستودع): {len(pairs)} | أصناف: {len(it_count)}"
      f" | مستودعات: {len(wh_count)} | زمن التشغيل: {time.time() - t0:.0f}ث")
    dates = [m["date"] for m in mv.values()]
    P(f"نطاق التواريخ: {_iso(min(dates))} → {_iso(max(dates))}")
    P()
    P("── ما الذي يقيسه هذا التقرير؟ ──")
    P("A) قياس مباشر لاستثناءات الحركات الموجودة (بلا محاكاة أحداث).")
    P("B) محاكاة أثرها على أحداث تصحيح افتراضية (كل حركة مؤهَّلة كأنها أُدخلت بأثر رجعي).")
    P("C) أحداث تصحيح حقيقية موجودة فعلاً في القاعدة.")
    P("المحرك: candidate_engine.build_candidate الفعلي، بلا قيم مصحَّحة (الحالة الأساسية).")
    P()
    P("══ A) استثناءات الحركات الموجودة ══")
    P("مباشر = OUT كميته السابقة ≤ 0 (DL-003) | تسميم = OUT كميته > 0 لكنه يلي استثناءً (DL-005)")
    P("وارث = ساق Transfer-IN مقابل لـOUT استثنائي (لا يُحسب مع المباشر/التسميم: لا عدّ مزدوج)")
    for w in per_wh:
        P(f"  {w['wh']}: حركات {w['movements']} | OUT {w['out']} | مباشر {w['direct']} "
          f"({_pct(w['direct'], w['out'])}) | تسميم {w['poisoned']} ({_pct(w['poisoned'], w['out'])})"
          f" | وارث-IN {w['inherited_in']} | أزواج بها استثناء {w['pairs_with_exception']}/{w['pairs']}")
    tot_out = sum(w["out"] for w in per_wh)
    td = sum(w["direct"] for w in per_wh); tp = sum(w["poisoned"] for w in per_wh)
    ti = sum(w["inherited_in"] for w in per_wh)
    P(f"  الإجمالي: OUT {tot_out} | مباشر {td} ({_pct(td, tot_out)}) | تسميم {tp} "
      f"({_pct(tp, tot_out)}) | وارث-IN {ti}")
    if unevA:
        P("  أزواج تعذّر تقييمها:", dict(unevA))
    P(f"  فحص ذاتي (OUT كميته ≤ 0 ولم يُعلِّمه المحرك): {contradictions} — يجب أن يكون 0")
    if pair_rows:
        P(f"  أعلى {min(args.top, len(pair_rows))} (صنف/مستودع) تأثراً — أبكر استثناء ثم OUT المتأثرة:")
        for r in pair_rows[:args.top]:
            P(f"    {r['item']}/{r['wh']}: أبكر استثناء {r['first_exception']} | OUT {r['out_total']} "
              f"| مباشر {r['direct']} | تسميم {r['poisoned']} | وارث-IN {r['inherited_in']}")
    P()
    P("══ B) محاكاة أحداث التصحيح الافتراضية ══")
    P("المقام = أحداث مؤهَّلة: (1) يوجد لاحق بتاريخ أحدث في نفس صنف/مستودع (شرط الاكتشاف)،")
    P("(2) نطاقها يحوي بيعاً خارجياً واحداً على الأقل. «محجوب» = يحوي أي صف استثنائي")
    P("(المنشئ يرفض الحدث كاملاً عند أي استثناء).")
    P(f"  مؤهَّلة: {E} | محجوبة: {B} ({_pct(B, E)}) | بلا بيع في النطاق (مستبعَدة): {NS}")
    P(f"  محجوبة وفيها استثناء مباشر (DL-003 وحده كان سيحجبها): {Bd} من {B}")
    if unevB:
        P("  أحداث تعذّر تقييمها:", dict(unevB))
    if since:
        P(f"  ⚠️ نافذة المحاكاة: أحداث افتراضية جذرها من {since} فصاعداً فقط.")
    if args.sample:
        P(f"  ⚠️ عيّنة: حتى {args.sample} نقطة تاريخية لكل صنف — النسب تقديرية.")
    if partial:
        P("  ⚠️ توقّفت المحاكاة عند السقف الزمني — النتائج جزئية.")
    P("  توزيع الأصناف حسب نسبة الأحداث المحجوبة:", dict(buckets))
    P(f"  أعلى {min(args.top, len(rows_B))} صنفاً بعدد الأحداث المحجوبة (نافذة الحجب = مدى تواريخ المحجوب):")
    for r in rows_B[:args.top]:
        if r["eligible"] == 0:
            continue
        P(f"    {r['item']}: مؤهَّلة {r['eligible']} | محجوبة {r['blocked']} ({r['ratio']:.0f}%)"
          + (f" | نافذة الحجب {r['blocked_from']} → {r['blocked_to']}" if r["blocked"] else "")
          + f" | مدى المؤهَّلة {r['eligible_from']} → {r['eligible_to']}")
    P()
    P("══ C) أحداث تصحيح حقيقية في القاعدة ══")
    P(f"  الإجمالي: {real['total']} | حسب الحالة: {dict(real['by_status'])}")
    P(f"  مؤهَّلة (فيها بيع): {real['eligible']} | محجوبة: {real['blocked']} "
      f"({_pct(real['blocked'], real['eligible'])}) | بلا بيع: {real['no_sales_out']}"
      f" | جذر غير مدعوم: {real['unsupported_root']}")
    if real["unevaluable"]:
        P("  تعذّر تقييمها:", dict(real["unevaluable"]))
    P()
    if trootA or trootB or real["transfer_root"]:
        P("── ⚠️ قصور نطاق معروف يمسّ هذا القياس ──")
        P(f"  أحداث/أزواج جذرها ساق تحويل OUT: A={trootA} | B={trootB} | C={real['transfer_root']}")
        P("  نطاق هذه الأحداث لا يعبر إلى مستودع الوجهة (الجذر يُتخطّى في حلقة العبور داخل")
        P("  correction_scope.walk_warehouse_branch). النتيجة: وراثة الاستثناء عبر التحويل قد")
        P("  تُقدَّر بأقل من حقيقتها، وقد يُستبعَد الحدث من المقام لأن بيع الوجهة لا يدخل نطاقه؛")
        P("  فنسب الحجب لهذه الحالات حدّ أدنى.")
        P()
    P("── تنبيهات القراءة ──")
    P("• DL-005 يضاعف عدد الصفوف الاستثنائية لكنه لا يغيّر أي الأحداث محجوب اليوم: المنشئ")
    P("  يرفض الحدث كاملاً عند أي استثناء (DL-003). أثر DL-005 الفعلي يظهر فقط لو سُمح")
    P("  لاحقاً بتصحيح جزئي يستبعد صفوف الاستثناء وحدها.")
    P("• B يفترض أن كل حركة مؤهَّلة قد تُدخَل بأثر رجعي؛ هو قياس إمكانية لا تاريخ أحداث وقعت.")
    P("• القياس للحالة الأساسية بلا قيم مصحَّحة؛ تصحيح كميات قد يضيف استثناءات.")
    P("• مرتجعات/إلغاءات داخل النطاق تُحسَب كحركات عادية هنا، وقد يرفضها المنشئ لأسباب أخرى.")

    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump({
                "file_unchanged": sha_before == sha_after, "movements": len(mv),
                "A": {"per_warehouse": per_wh, "pairs": pair_rows,
                      "unevaluable": dict(unevA), "self_check_contradictions": contradictions,
                      "transfer_out_root_pairs": trootA},
                "B": {"eligible": E, "blocked": B, "blocked_with_direct": Bd,
                      "excluded_no_sales_out": NS, "transfer_out_root_events": trootB,
                      "unevaluable": dict(unevB),
                      "partial": partial, "sample": args.sample, "since": args.since, "items": rows_B},
                "C": {**real, "by_status": dict(real["by_status"]),
                      "unevaluable": dict(real["unevaluable"])},
            }, f, ensure_ascii=False, indent=2)
        P(f"\n(JSON المجمَّع: {args.json})")
    if args.map_out:
        with open(args.map_out, "w", encoding="utf-8") as f:
            f.write("# جدول التسميات — للاستخدام المحلي فقط، لا تُرسله\n")
            for i, lab in sorted(ilabel.items(), key=lambda kv: kv[1]):
                f.write(f"{lab}\titem_id={i}\n")
            for w, lab in sorted(wlabel.items(), key=lambda kv: kv[1]):
                f.write(f"{lab}\twarehouse_id={w}\n")
        P(f"(جدول التسميات المحلي: {args.map_out})")
    return 0 if sha_before == sha_after else 3


if __name__ == "__main__":
    raise SystemExit(main())
