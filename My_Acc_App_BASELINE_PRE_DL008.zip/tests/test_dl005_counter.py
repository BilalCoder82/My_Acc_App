"""
tests/test_dl005_counter.py
===========================
أداة القياس dl005_counter.py (قراءة فقط). كل رقم متوقَّع في T1 مشتَقّ يدوياً من
منطق DL-002/003/005 قبل التشغيل. T5 اختبار فرق عشوائي: القيم المتوقَّعة تُحسَب
بكود مستقل كلياً (لا يستدعي المحرك) ثم تُقارَن بمخرجات الأداة.
"""
import contextlib, datetime as dt, io, json, os, random, sqlite3, sys, tempfile
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from decimal import Decimal as D_
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import (Base, Setting, CostMethod, Warehouse, InventoryMovement,
                        MovementDirection, StockTransfer, CorrectionEvent)
from app.services.chart_of_accounts_template import create_default_chart_of_accounts
from app.services.correction_detection import attach_detection_listeners
from app.services.item_edit import create_item
from app.services.posting import get_default_warehouse
import dl005_counter as counter

results = []


def check(label, cond, detail=""):
    results.append("PASS" if cond else "FAIL")
    print(f"[{'PASS' if cond else 'FAIL'}] {label}" + (f" — {detail}" if detail else ""))


IN, OUT = MovementDirection.IN, MovementDirection.OUT
SECRET_WH = "مستودع-سري-XYZ"


def new_db(path):
    if os.path.exists(path):
        os.remove(path)
    attach_detection_listeners()          # كالتطبيق: الإدخال بأثر رجعي ينتج أحداثاً حقيقية
    eng = create_engine(f"sqlite:///{path}")
    Base.metadata.create_all(eng)
    s = sessionmaker(bind=eng)()
    coa = create_default_chart_of_accounts(s)
    s.add(Setting(key="base_currency", value="SYP")); s.commit()
    W1 = get_default_warehouse(s)
    W2 = Warehouse(name_ar=SECRET_WH); s.add(W2); s.commit()
    return s, coa, W1, W2


def make_item(s, coa, sku):
    return create_item(s, sku=sku, name_ar=f"صنف-سري-{sku}", unit="u",
                       inventory_account_id=coa["inventory"].id, cogs_account_id=coa["cogs"].id,
                       sales_account_id=coa["sales"].id, cost_method=CostMethod.AVERAGE)


def mov(s, it, wh, direction, q, date, src, sid=1, cost=10):
    s.add(InventoryMovement(item_id=it.id, warehouse_id=wh.id, direction=direction,
                            quantity=D_(str(q)), unit_cost=D_(str(cost)), movement_date=date,
                            source_type=src, source_id=sid))
    s.commit()


def run_counter(path, *extra):
    buf = io.StringIO()
    jpath = path + ".json"
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(io.StringIO()):
        rc = counter.main([path, "--json", jpath, "--quiet", *extra])
    return rc, buf.getvalue(), json.load(open(jpath, encoding="utf-8"))


d = lambda m, dd: dt.date(2026, m, dd)

# =========================================================================
# T1 — مجموعة بيانات بأجوبة محسوبة يدوياً
# =========================================================================
tmp = tempfile.mkdtemp()
path = os.path.join(tmp, "fx.db")
s, coa, W1, W2 = new_db(path)
A, B, C, Dd, E, F = (make_item(s, coa, x) for x in "ABCDEF")
mov(s, A, W1, IN, 10, d(1, 1), "purchase_invoice"); mov(s, A, W1, OUT, 4, d(1, 10), "sales_invoice")
mov(s, A, W1, IN, 5, d(1, 20), "purchase_invoice"); mov(s, A, W1, OUT, 3, d(2, 1), "sales_invoice")
mov(s, B, W1, OUT, 2, d(1, 5), "sales_invoice", cost=0); mov(s, B, W1, IN, 10, d(1, 8), "purchase_invoice")
mov(s, B, W1, OUT, 3, d(1, 12), "sales_invoice"); mov(s, B, W1, OUT, 1, d(1, 20), "sales_invoice")
mov(s, B, W1, IN, 5, d(1, 25), "purchase_invoice")
t = StockTransfer(transfer_no="T1", transfer_date=d(1, 3), item_id=C.id, from_warehouse_id=W1.id,
                  to_warehouse_id=W2.id, quantity=D_("3")); s.add(t); s.commit()
mov(s, C, W1, IN, 2, d(1, 1), "purchase_invoice"); mov(s, C, W1, OUT, 2, d(1, 2), "sales_invoice")
mov(s, C, W1, OUT, 3, d(1, 3), "stock_transfer", t.id, cost=0)
mov(s, C, W2, IN, 3, d(1, 3), "stock_transfer", t.id, cost=0)
mov(s, C, W2, OUT, 1, d(1, 6), "sales_invoice"); mov(s, C, W1, IN, 6, d(1, 9), "purchase_invoice")
mov(s, C, W1, OUT, 2, d(1, 15), "sales_invoice")
mov(s, Dd, W1, IN, 5, d(1, 10), "purchase_invoice"); mov(s, Dd, W1, OUT, 2, d(1, 5), "sales_invoice", cost=0)
mov(s, E, W1, IN, 10, d(1, 1), "purchase_invoice"); mov(s, E, W1, OUT, 2, d(2, 1), "sales_invoice")
mov(s, E, W1, IN, 5, d(1, 15), "purchase_invoice")
mov(s, F, W1, IN, 5, d(1, 1), "purchase_invoice"); mov(s, F, W1, IN, 5, d(1, 3), "purchase_invoice")
ev_before = s.query(CorrectionEvent).count()
s.close()

copy = os.path.join(tmp, "copy.db")
open(copy, "wb").write(open(path, "rb").read())
rc, text, J = run_counter(copy)
pw = {w["wh"]: w for w in J["A"]["per_warehouse"]}
tot = lambda k: sum(w[k] for w in J["A"]["per_warehouse"])
check("T1.1 A: مباشر=3 (B/C-تحويل/D)، تسميم=4، وارث-IN=1 (لا عدّ مزدوج)",
      (tot("direct"), tot("poisoned"), tot("inherited_in")) == (3, 4, 1),
      str((tot("direct"), tot("poisoned"), tot("inherited_in"))))
check("T1.2 A: OUT=11، حركات=23، أزواج بها استثناء 4 من 7",
      tot("out") == 11 and J["movements"] == 23 and sum(w["pairs_with_exception"] for w in pw.values()) == 4
      and sum(w["pairs"] for w in pw.values()) == 7)
check("T1.3 A: وراثة التحويل في المستودع الوجهة (وارث-IN=1، تسميم=1) والفحص الذاتي 0",
      pw["W2"]["inherited_in"] == 1 and pw["W2"]["poisoned"] == 1 and J["A"]["self_check_contradictions"] == 0)
Bj = J["B"]
check("T1.4 B: مؤهَّلة=15، محجوبة=5، مستبعَدة بلا بيع=1",
      (Bj["eligible"], Bj["blocked"], Bj["excluded_no_sales_out"]) == (15, 5, 1),
      str((Bj["eligible"], Bj["blocked"], Bj["excluded_no_sales_out"])))
check("T1.5 B: كل المحجوب فيه استثناء مباشر (DL-003 وحده يحجبها) — DL-005 لا يغيّر الحجب",
      Bj["blocked_with_direct"] == Bj["blocked"] == 5)
items = {r["item"]: r for r in Bj["items"]}
check("T1.6 B: توزيع الأصناف المحجوبة (4/1، 5/3، 1/1) ونافذة الحجب لصنف التحويل 01-01→01-03",
      sorted((r["eligible"], r["blocked"]) for r in Bj["items"] if r["blocked"]) == [(1, 1), (4, 1), (5, 3)]
      and any(r["blocked_from"] == "2026-01-01" and r["blocked_to"] == "2026-01-03" for r in Bj["items"]))
Cj = J["C"]
check("T1.7 C: أحداث حقيقية 2 (حدثان من الاكتشاف)، مؤهَّلة 2، محجوبة 1",
      (Cj["total"], Cj["eligible"], Cj["blocked"]) == (2, 2, 1) and Cj["total"] == ev_before,
      str((Cj["total"], Cj["eligible"], Cj["blocked"], ev_before)))
check("T1.8 تقييد: جذر ساق تحويل OUT يُرصَد (B=1)", Bj["transfer_out_root_events"] == 1)

# =========================================================================
# T2 — القراءة فقط
# =========================================================================
import hashlib
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
h0, m0 = sha(copy), os.path.getmtime(copy)
rc2, _, _ = run_counter(copy)
check("T2.1 الملف لم يتغيّر بعد التشغيل (SHA-256 وmtime) ورمز الخروج 0",
      sha(copy) == h0 and os.path.getmtime(copy) == m0 and rc2 == 0 and J["file_unchanged"])
con = sqlite3.connect(counter.Path(copy).resolve().as_uri() + "?mode=ro", uri=True)
try:
    con.execute("CREATE TABLE zz(x)"); wrote = True
except sqlite3.OperationalError:
    wrote = False
con.close()
check("T2.2 اتصال القراءة فقط يرفض أي كتابة (الآلية المستخدمة فعلاً)", not wrote)
con = sqlite3.connect(copy)
n_events = con.execute("SELECT count(*) FROM correction_events").fetchone()[0]
n_cands = con.execute("SELECT count(*) FROM correction_event_candidate_states").fetchone()[0]
con.close()
check("T2.3 لا أحداث/مرشَّحات جديدة في الملف (2 أحداث، 0 مرشَّح)", (n_events, n_cands) == (2, 0), str((n_events, n_cands)))

# =========================================================================
# T3 — إخراج مجمَّع بلا أسماء ولا مبالغ
# =========================================================================
leaks = [x for x in (SECRET_WH, "صنف-سري") if x in text]
check("T3.1 التقرير لا يحوي أسماء أصناف/مستودعات", not leaks, str(leaks))
with open(os.path.join(tmp, "map.txt"), "w") as f:
    pass
rc3, text3, _ = run_counter(copy, "--map-out", os.path.join(tmp, "map.txt"))
check("T3.2 جدول التسميات يُكتب إلى الملف فقط (لا يُطبَع)",
      "item_id=" in open(os.path.join(tmp, "map.txt"), encoding="utf-8").read() and "item_id=" not in text3)

# =========================================================================
# T4 — كاناري: جذر ساق تحويل OUT (قصور نطاق معروف) — يوثّق السلوك الحالي
# =========================================================================
p4 = os.path.join(tmp, "t4.db")
s, coa, W1, W2 = new_db(p4)
H = make_item(s, coa, "H")
t4 = StockTransfer(transfer_no="T4", transfer_date=d(1, 3), item_id=H.id, from_warehouse_id=W1.id,
                   to_warehouse_id=W2.id, quantity=D_("2")); s.add(t4); s.commit()
mov(s, H, W1, OUT, 2, d(1, 3), "stock_transfer", t4.id, cost=0); mov(s, H, W2, IN, 2, d(1, 3), "stock_transfer", t4.id, cost=0)
mov(s, H, W2, OUT, 1, d(1, 8), "sales_invoice"); mov(s, H, W1, IN, 5, d(1, 9), "purchase_invoice")
s.close()
_, _, J4 = run_counter(p4)
check("T4.1 زوج جذره ساق تحويل OUT يُرصَد في A (=1) وفي B (≥1)",
      J4["A"]["transfer_out_root_pairs"] == 1 and J4["B"]["transfer_out_root_events"] >= 1)
inh = sum(w["inherited_in"] for w in J4["A"]["per_warehouse"])
check("T4.2 [كاناري] السلوك الحالي: النطاق لا يعبر لمستودع الوجهة ⟹ وراثة=0 (إن صُحِّح القصور يجب تحديث هذا الاختبار)",
      inh == 0, f"inherited_in={inh}")

# =========================================================================
# T6 — OUT تحويل وحده ليس تعرّضاً لـCOGS: نطاق بلا بيع يُستبعَد من المقام
#   I: W1: IN 5 (1/1) ، OUT تحويل 2 (1/3) ، IN 3 (1/9) ؛ W2: IN 2 (1/3).
#   أحداث مؤهَّلة بالاكتشاف: جذر 1/1 وجذر 1/3 (لكل منهما لاحق بتاريخ أحدث) ⟹ كلاهما
#   بلا بيع في النطاق ⟹ مؤهَّلة 0، مستبعَدة 2.
# =========================================================================
p6 = os.path.join(tmp, "t6.db")
s, coa, W1, W2 = new_db(p6)
I = make_item(s, coa, "I")
t6 = StockTransfer(transfer_no="T6", transfer_date=d(1, 3), item_id=I.id, from_warehouse_id=W1.id,
                   to_warehouse_id=W2.id, quantity=D_("2")); s.add(t6); s.commit()
mov(s, I, W1, IN, 5, d(1, 1), "purchase_invoice"); mov(s, I, W1, OUT, 2, d(1, 3), "stock_transfer", t6.id)
mov(s, I, W2, IN, 2, d(1, 3), "stock_transfer", t6.id); mov(s, I, W1, IN, 3, d(1, 9), "purchase_invoice")
s.close()
_, _, J6 = run_counter(p6)
check("T6 نطاق فيه OUT تحويل فقط بلا بيع ⟹ مؤهَّلة=0، مستبعَدة=2 (لا يُحسب تعرّضاً لـCOGS)",
      (J6["B"]["eligible"], J6["B"]["excluded_no_sales_out"]) == (0, 2),
      str((J6["B"]["eligible"], J6["B"]["excluded_no_sales_out"])))

# T7 — --since: يقصر المحاكاة B على جذور من التاريخ فصاعداً، ولا يمسّ A
#   جذور مؤهَّلة بالاكتشاف بتاريخ >= 1/10: A(1/10،1/20) B(1/12،1/20) E(1/15) ⟹ 5، كلها نظيفة.
_, _, J7 = run_counter(copy, "--since", "2026-01-10")
check("T7 --since 2026-01-10: مؤهَّلة=5 محجوبة=0، وقياس A لا يتغيّر (مباشر 3، تسميم 4)",
      (J7["B"]["eligible"], J7["B"]["blocked"]) == (5, 0)
      and sum(w["direct"] for w in J7["A"]["per_warehouse"]) == 3
      and sum(w["poisoned"] for w in J7["A"]["per_warehouse"]) == 4,
      str((J7["B"]["eligible"], J7["B"]["blocked"])))

# =========================================================================
# T5 — فرق عشوائي: توقّع مستقل (مستودع واحد، بلا تحويلات)
# =========================================================================
def oracle(movs):
    """movs: [(item, date, is_out)] بترتيب الإدخال (= id). توقّع مستقل كلياً."""
    from collections import defaultdict
    by = defaultdict(list)
    for idx, (it, dte, out, q) in enumerate(movs):
        by[it].append((dte, idx, out, q))
    direct = poisoned = E = B = 0
    for it, rows in by.items():
        rows.sort()                                   # (تاريخ، ترتيب الإدخال)
        q = 0; tainted = False; qb = {}
        for dte, idx, out, qty in rows:
            qb[idx] = q
            if out:
                if q <= 0:
                    direct += 1; tainted = True
                elif tainted:
                    poisoned += 1
                q -= qty
            else:
                q += qty
        for dte, idx, out, qty in rows:
            if not any(r[0] > dte for r in rows):
                continue                              # لا لاحق بتاريخ أحدث ⟹ غير مؤهَّل
            scope_out = [r for r in rows if r[0] >= dte and r[2]]
            if not scope_out:
                continue                              # لا بيع في النطاق
            E += 1
            if any(qb[r[1]] <= 0 for r in scope_out):
                B += 1
    return direct, poisoned, E, B


rng = random.Random(20261004)
fails = 0
SEEDS = 30
for seed in range(SEEDS):
    p = os.path.join(tmp, f"f{seed}.db")
    s, coa, W1, _w2 = new_db(p)
    its = [make_item(s, coa, f"R{k}") for k in range(rng.randint(1, 3))]
    movs = []
    for k, it in enumerate(its):
        for _ in range(rng.randint(2, 11)):
            out = rng.random() < 0.5
            dte = d(1, rng.randint(1, 8)); qty = rng.randint(1, 5)
            mov(s, it, W1, OUT if out else IN, qty, dte,
                "sales_invoice" if out else "purchase_invoice")
            movs.append((k, dte, out, qty))
    s.close()
    _, _, Jf = run_counter(p)
    got = (sum(w["direct"] for w in Jf["A"]["per_warehouse"]),
           sum(w["poisoned"] for w in Jf["A"]["per_warehouse"]),
           Jf["B"]["eligible"], Jf["B"]["blocked"])
    exp = oracle(movs)
    if got != exp or Jf["A"]["self_check_contradictions"] != 0:
        fails += 1
        print(f"   ✗ seed {seed}: أداة={got} متوقَّع={exp}")
check(f"T5 فرق عشوائي: {SEEDS} قاعدة، (مباشر، تسميم، مؤهَّلة، محجوبة) = التوقّع المستقل", fails == 0, f"{fails} مخالفة")

passed = results.count("PASS")
print(f"\nDL-005 counter test summary: {passed}/{len(results)} PASS")
sys.exit(0 if passed == len(results) else 1)
